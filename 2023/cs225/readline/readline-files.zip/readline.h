#ifndef READLINE_H
#define READLINE_H
#include <stdio.h>
/* returns a pointer to an array of character contatining the string */
char * readline( FILE * );
#endif
