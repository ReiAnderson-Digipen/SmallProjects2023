#ifndef THREEDDA_H
#define THREEDDA_H
int *** allocate  ( int d1, int d2, int d3 );
void    deallocate( int *** ppp );
#endif
