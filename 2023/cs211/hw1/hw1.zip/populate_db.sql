use HW1;
load DATA infile '../Uploads/hw1/forumUser.txt' into table forumUser columns terminated by '|';
load DATA infile '../Uploads/hw1/administrator.txt' into table administrator columns terminated by '|';
load DATA infile '../Uploads/hw1/browse.txt' into table browse columns terminated by '|';
load DATA infile '../Uploads/hw1/forumPost.txt' into table forumPost columns terminated by '|';
load DATA infile '../Uploads/hw1/forumSection.txt' into table forumSection columns terminated by '|';
load DATA infile '../Uploads/hw1/forumVisitor.txt' into table forumVisitor columns terminated by '|';
load DATA infile '../Uploads/hw1/operate.txt' into table operate columns terminated by '|';
load DATA infile '../Uploads/hw1/postReply.txt' into table postReply columns terminated by '|';
load DATA infile '../Uploads/hw1/visit.txt' into table visit columns terminated by '|';


