use imstagram;

# group_concat('drop table if exists ', table_name, ';')
drop table if exists album;
drop table if exists event;
drop table if exists eventparticipant;
drop table if exists friendship;
drop table if exists message;
drop table if exists photo;
drop table if exists profileinformation;
drop table if exists tags;
drop table if exists users;
